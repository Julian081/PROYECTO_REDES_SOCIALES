package controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.PublicacionVo;
import model.PublicacionDao;

public class Servletnavegacion extends HttpServlet {

      PublicacionVo generoVo = new PublicacionVo();
      PublicacionDao generoDao = new PublicacionDao();

      protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
            String pagina = req.getParameter("quiero");
            switch (pagina) {
                  case "empezemos":
                        System.out.println(pagina);
                        req.getRequestDispatcher("../webapp/n/login.jsp").forward(req, resp);
                        break;
                  case "bienvenido":
                        System.out.println(pagina);
                        req.getRequestDispatcher("../webapp/n/datos.jsp").forward(req, resp);
                        break;
                  case "publicaciones":
                        System.out.println(pagina);
                        req.getRequestDispatcher("../../webapp/index.jsp").forward(req, resp);
                        break;
                  case "index":
                        System.out.println(pagina);
                        req.getRequestDispatcher("../webapp/n/index_re.jsp").forward(req, resp);
                        break;

                  case "VolverP":
                        System.out.println(pagina);
                        req.getRequestDispatcher("../webapp/n/index_re.jsp").forward(req, resp);
                        break;
                  default:
                        System.out.println("VOLVER");
                        break;
            }

      }

}
